@echo off
cd /d "%~dp0"

if not exist venv (
    echo Creating virtual environment...
    python -m venv venv
)

call venv\Scripts\activate

echo Upgrading pip...
python -m pip install --upgrade pip

echo Installing CUDA-enabled PyTorch and Torchvision (nightly cu130 for Blackwell support)...
pip install --pre --upgrade torch torchvision --index-url https://download.pytorch.org/whl/nightly/cu130

echo Installing requirements...
pip install -r requirements.txt

echo Checking and downloading required models...
python backend/download_models.py
if %errorlevel% neq 0 (
    echo [ERROR] Model download failed. Exiting...
    pause
    exit /b 1
)

echo Starting ANIMA-Tagger...
python backend/main.py

pause
