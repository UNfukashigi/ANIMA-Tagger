let currentDatasetImages = [];
let activeEditImage = null;
let activeEditTags = [];

// DOM Elements
const elFolderPath = document.getElementById("folder-path");
const elTriggerWord = document.getElementById("trigger-word");
const elBtnBrowse = document.getElementById("btn-browse");
const elBtnRun = document.getElementById("btn-run");
const elConsole = document.getElementById("console");

const elBtnLoadDataset = document.getElementById("btn-load-dataset");
const elDatasetGrid = document.getElementById("dataset-grid");
const elBtnBulkEdit = document.getElementById("btn-bulk-edit");

// Modal Elements
const elEditModal = document.getElementById("edit-modal");
const elModalImg = document.getElementById("modal-img");
const elModalTagsContainer = document.getElementById("modal-tags-container");
const elNewTagInput = document.getElementById("new-tag-input");
const elBtnAddTag = document.getElementById("btn-add-tag");
const elBtnSaveTags = document.getElementById("btn-save-tags");
const elBtnCancelEdit = document.getElementById("btn-cancel-edit");
const elBtnCloseModal = document.getElementById("btn-close-modal");

const elBulkEditModal = document.getElementById("bulk-edit-modal");
const elBulkTagInput = document.getElementById("bulk-tag-input");
const elBulkTagSuggestions = document.getElementById("bulk-tag-suggestions");
const elBulkTagsContainer = document.getElementById("bulk-tags-container");
const elBtnBulkAdd = document.getElementById("btn-bulk-add");
const elBtnBulkTriggerAdd = document.getElementById("btn-bulk-trigger-add");
const elBtnBulkRemove = document.getElementById("btn-bulk-remove");
const elBtnCancelBulkEdit = document.getElementById("btn-cancel-bulk-edit");
const elBtnCloseBulkModal = document.getElementById("btn-close-bulk-modal");

// Write to web log terminal
function logToConsole(text) {
    if (text.includes("\r")) {
        const lines = elConsole.textContent.split("\n");
        const parts = text.split("\r");
        // Overwrite the last line with the new update
        lines[lines.length - 1] = parts[parts.length - 1];
        elConsole.textContent = lines.join("\n");
    } else {
        elConsole.textContent += text;
    }
    elConsole.scrollTop = elConsole.scrollHeight;
}

// Folder dialog setup
elBtnBrowse.addEventListener("click", async () => {
    try {
        const response = await fetch("/api/browse-folder");
        const data = await response.json();
        if (data.path) {
            elFolderPath.value = data.path;
            loadDataset(data.path);
        }
    } catch (e) {
        alert("フォルダの選択に失敗しました: " + e.message);
    }
});

// Reload Dataset
elBtnLoadDataset.addEventListener("click", () => {
    const path = elFolderPath.value.strip ? elFolderPath.value.trim() : elFolderPath.value;
    if (!path) {
        alert("フォルダが指定されていません。");
        return;
    }
    loadDataset(path);
});

async function loadDataset(folderPath) {
    try {
        const response = await fetch(`/api/dataset/images?path=${encodeURIComponent(folderPath)}`);
        if (!response.ok) throw new Error("Dataset path invalid");
        
        const data = await response.json();
        currentDatasetImages = data.files;
        renderDatasetGrid();
    } catch (e) {
        alert("データセットの読み込みに失敗しました: " + e.message);
    }
}

function renderDatasetGrid() {
    elDatasetGrid.innerHTML = "";
    
    if (currentDatasetImages.length === 0) {
        elDatasetGrid.innerHTML = `
            <div class="empty-state">
                <p>フォルダ内に画像ファイルが見つかりません。</p>
            </div>
        `;
        return;
    }
    
    currentDatasetImages.forEach(img => {
        const card = document.createElement("div");
        card.className = "img-card";
        
        const tagsHtml = img.tags.map(t => `<span class="tag-badge ${getTagClass(t)}">${escapeHtml(t)}</span>`).join("");
        
        card.innerHTML = `
            <div class="img-card-preview">
                <img src="/api/image?path=${encodeURIComponent(img.path)}" alt="${img.name}" loading="lazy">
            </div>
            <div class="img-card-info">
                <div class="img-filename">${img.name}</div>
                <div class="tags-preview">${tagsHtml || '<span class="text-muted" style="font-size: 11px;">タグ未生成</span>'}</div>
            </div>
        `;
        
        card.addEventListener("click", () => openEditModal(img));
        elDatasetGrid.appendChild(card);
    });
}

function escapeHtml(value) {
    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");
}

function getTagClass(tag) {
    const normalized = String(tag).trim().toLowerCase();
    const trigger = elTriggerWord.value.trim().toLowerCase();
    if (trigger && normalized === trigger) return "tag-trigger";

    const styleWords = [
        "style", "lineart", "outline", "shading", "cel shading", "flat color", "tone",
        "pastel", "vivid", "muted", "contrast", "lighting", "backlighting", "rim lighting",
        "composition", "rendering", "anime", "matte", "comic", "detailed"
    ];
    const backgroundWords = [
        "background", "white background", "simple background", "transparent background",
        "no background", "indoors", "outdoors", "sky", "room", "street", "window"
    ];
    const poseWords = [
        "standing", "sitting", "lying", "kneeling", "walking", "running", "pose",
        "looking", "smile", "open mouth", "closed mouth", "blush", "crying", "angry",
        "happy", "sad", "jitome", "tsurime", "waving", "hand", "arms", "from above",
        "from below", "upper body", "full body", "portrait", "cowboy shot"
    ];
    const characterWords = [
        "girl", "boy", "solo", "hair", "eyes", "breasts", "shirt", "skirt", "dress",
        "sleeves", "collar", "hoodie", "sweater", "shoes", "sneakers", "bangs",
        "ahoge", "accessory", "ribbon", "bow", "uniform", "t-shirt", "skin", "mouth",
        "nose", "eyelashes"
    ];

    if (styleWords.some(word => normalized.includes(word))) return "tag-style";
    if (backgroundWords.some(word => normalized.includes(word))) return "tag-background";
    if (poseWords.some(word => normalized.includes(word))) return "tag-pose";
    if (characterWords.some(word => normalized.includes(word))) return "tag-character";
    return "tag-other";
}

// Websocket Logging setup
let ws = null;
let logPollInterval = null;
function connectWebSocket() {
    if (ws) ws.close();
    
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    ws = new WebSocket(`${protocol}//${window.location.host}/ws/logs`);
    
    ws.onmessage = (event) => {
        logToConsole(event.data);
    };
    
    ws.onclose = () => {
        console.log("WebSocket logs connection closed.");
    };
}

async function refreshLogs() {
    let response;
    try {
        response = await fetch("/api/tagger-logs");
    } catch (e) {
        return;
    }
    if (!response.ok) return;

    const data = await response.json();
    elConsole.textContent = data.logs || "";
    elConsole.scrollTop = elConsole.scrollHeight;
}

function startLogPolling() {
    stopLogPolling();
    refreshLogs();
    logPollInterval = setInterval(refreshLogs, 1000);
}

function stopLogPolling() {
    if (logPollInterval) {
        clearInterval(logPollInterval);
        logPollInterval = null;
    }
}

// Run Qwen-VL tagger
elBtnRun.addEventListener("click", async () => {
    const folderPath = elFolderPath.value;
    const triggerWord = elTriggerWord.value;
    
    if (!folderPath) {
        alert("処理するフォルダを指定してください。");
        return;
    }
    
    elBtnRun.disabled = true;
    elBtnRun.textContent = "処理中...";
    elConsole.textContent = "";
    connectWebSocket();
    
    try {
        const response = await fetch("/api/run-tagger", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                folder_path: folderPath,
                trigger_word: triggerWord
            })
        });
        
        const data = await response.json();
        if (data.status === "error") {
            alert("エラー: " + data.message);
            elBtnRun.disabled = false;
            elBtnRun.innerHTML = `<span class="icon">🚀</span> 自動タグ付けを開始`;
        } else {
            // Start polling status
            startLogPolling();
            monitorTaggerProgress();
        }
    } catch (e) {
        alert("タグ付け開始リクエストに失敗しました: " + e.message);
        elBtnRun.disabled = false;
        elBtnRun.innerHTML = `<span class="icon">🚀</span> 自動タグ付けを開始`;
    }
});

// Poll dataset periodically while running
function monitorTaggerProgress() {
    const interval = setInterval(async () => {
        const path = elFolderPath.value;
        if (path) {
            await loadDataset(path);
        }
        
        const response = await fetch("/api/tagger-status");
        const status = await response.json();
        if (!status.running) {
            clearInterval(interval);
            await refreshLogs();
            stopLogPolling();
            elBtnRun.disabled = false;
            elBtnRun.innerHTML = `<span class="icon">🚀</span> 自動タグ付けを開始`;
        }
    }, 3000);
}

// Modal Handlers
function openEditModal(img) {
    activeEditImage = img;
    activeEditTags = [...img.tags];
    
    elModalImg.src = `/api/image?path=${encodeURIComponent(img.path)}`;
    renderModalTags();
    
    elEditModal.style.display = "flex";
}

function renderModalTags() {
    elModalTagsContainer.innerHTML = "";
    activeEditTags.forEach((tag, idx) => {
        const tagEl = document.createElement("span");
        tagEl.className = `interactive-tag ${getTagClass(tag)}`;
        tagEl.textContent = tag;
        tagEl.addEventListener("click", () => removeTag(idx));
        elModalTagsContainer.appendChild(tagEl);
    });
}

function removeTag(index) {
    activeEditTags.splice(index, 1);
    renderModalTags();
}

function parseTagsFromInput(value) {
    return value
        .split(",")
        .map(t => t.trim())
        .filter(t => t.length > 0 && !/^\d+$/.test(t));
}

function getAllDatasetTags() {
    const seen = new Set();
    const tags = [];
    currentDatasetImages.forEach(img => {
        img.tags.forEach(tag => {
            const normalized = tag.trim();
            const key = normalized.toLowerCase();
            if (normalized && !/^\d+$/.test(normalized) && !seen.has(key)) {
                seen.add(key);
                tags.push(normalized);
            }
        });
    });
    return tags;
}

function renderBulkEditor() {
    const tags = getAllDatasetTags();
    const sortedTags = [...tags].sort((a, b) => a.localeCompare(b));
    elBulkTagSuggestions.innerHTML = sortedTags
        .map(tag => `<option value="${escapeHtml(tag)}"></option>`)
        .join("");
    elBulkTagsContainer.innerHTML = "";

    if (tags.length === 0) {
        elBulkTagsContainer.innerHTML = '<span class="text-muted" style="font-size: 12px;">タグがありません</span>';
        return;
    }

    tags.forEach(tag => {
        const tagEl = document.createElement("span");
        tagEl.className = `interactive-tag ${getTagClass(tag)}`;
        tagEl.textContent = tag;
        tagEl.title = "クリックで一括削除";
        tagEl.addEventListener("click", () => confirmBulkRemoveTag(tag));
        elBulkTagsContainer.appendChild(tagEl);
    });
}

function openBulkEditor() {
    if (currentDatasetImages.length === 0) {
        alert("先にデータセットを読み込んでください。");
        return;
    }
    elBulkTagInput.value = "";
    renderBulkEditor();
    elBulkEditModal.style.display = "flex";
}

function closeBulkEditor() {
    elBulkEditModal.style.display = "none";
}

async function saveDatasetImageTags(img) {
    const response = await fetch("/api/dataset/update-tags", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            path: img.path,
            tags: img.tags
        })
    });
    if (!response.ok) {
        throw new Error(img.name);
    }
}

async function saveAllDatasetTags() {
    for (const img of currentDatasetImages) {
        await saveDatasetImageTags(img);
    }
    renderDatasetGrid();
    renderBulkEditor();
}

async function bulkAddTags() {
    const tagsToAdd = parseTagsFromInput(elBulkTagInput.value);
    if (tagsToAdd.length === 0) return;

    currentDatasetImages.forEach(img => {
        const existing = new Set(img.tags.map(tag => tag.toLowerCase()));
        tagsToAdd.forEach(tag => {
            if (!existing.has(tag.toLowerCase())) {
                img.tags.push(tag);
                existing.add(tag.toLowerCase());
            }
        });
    });

    try {
        await saveAllDatasetTags();
        elBulkTagInput.value = "";
    } catch (e) {
        alert("一括追加の保存に失敗しました: " + e.message);
    }
}

async function bulkAddTriggerWords() {
    const tagsToAdd = parseTagsFromInput(elBulkTagInput.value);
    if (tagsToAdd.length === 0) return;

    currentDatasetImages.forEach(img => {
        const triggerSet = new Set(tagsToAdd.map(tag => tag.toLowerCase()));
        const remainingTags = img.tags.filter(tag => !triggerSet.has(tag.toLowerCase()));
        img.tags = [...tagsToAdd, ...remainingTags];
    });

    try {
        await saveAllDatasetTags();
        elBulkTagInput.value = "";
    } catch (e) {
        alert("トリガーワード追加の保存に失敗しました: " + e.message);
    }
}

async function bulkRemoveTags(tagsToRemove) {
    if (tagsToRemove.length === 0) return;

    const removeSet = new Set(tagsToRemove.map(tag => tag.toLowerCase()));
    currentDatasetImages.forEach(img => {
        img.tags = img.tags.filter(tag => !removeSet.has(tag.toLowerCase()));
    });

    try {
        await saveAllDatasetTags();
        elBulkTagInput.value = "";
    } catch (e) {
        alert("一括削除の保存に失敗しました: " + e.message);
    }
}

function confirmBulkRemoveTag(tag) {
    if (confirm(`${tag} を一括削除しますか？`)) {
        bulkRemoveTags([tag]);
    }
}

function bulkRemoveFromInput() {
    const tagsToRemove = parseTagsFromInput(elBulkTagInput.value);
    if (tagsToRemove.length === 0) return;

    if (confirm(`${tagsToRemove.join(", ")} を一括削除しますか？`)) {
        bulkRemoveTags(tagsToRemove);
    }
}

function addTagsFromInput() {
    const rawInput = elNewTagInput.value.trim();
    if (!rawInput) return;
    
    // Split by comma
    const tags = parseTagsFromInput(rawInput);
    tags.forEach(tag => {
        if (!activeEditTags.includes(tag)) {
            activeEditTags.push(tag);
        }
    });
    
    elNewTagInput.value = "";
    renderModalTags();
}

// Trigger tag addition on Enter key or button click
elNewTagInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
        e.preventDefault();
        addTagsFromInput();
    }
});
elBtnAddTag.addEventListener("click", addTagsFromInput);
elBtnBulkEdit.addEventListener("click", openBulkEditor);
elBtnBulkAdd.addEventListener("click", bulkAddTags);
elBtnBulkTriggerAdd.addEventListener("click", bulkAddTriggerWords);
elBtnBulkRemove.addEventListener("click", bulkRemoveFromInput);
elBtnCancelBulkEdit.addEventListener("click", closeBulkEditor);
elBtnCloseBulkModal.addEventListener("click", closeBulkEditor);
elBulkTagInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
        e.preventDefault();
        bulkAddTags();
    }
});

// Save tags action
elBtnSaveTags.addEventListener("click", async () => {
    if (!activeEditImage) return;
    
    try {
        const response = await fetch("/api/dataset/update-tags", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                path: activeEditImage.path,
                tags: activeEditTags
            })
        });
        
        if (response.ok) {
            closeModal();
            loadDataset(elFolderPath.value);
        } else {
            alert("保存に失敗しました。");
        }
    } catch (e) {
        alert("保存エラー: " + e.message);
    }
});

// Close modal handlers
function closeModal() {
    elEditModal.style.display = "none";
    activeEditImage = null;
    activeEditTags = [];
}

elBtnCancelEdit.addEventListener("click", closeModal);
elBtnCloseModal.addEventListener("click", closeModal);
window.addEventListener("click", (e) => {
    if (e.target === elEditModal) {
        closeModal();
    }
    if (e.target === elBulkEditModal) {
        closeBulkEditor();
    }
});
