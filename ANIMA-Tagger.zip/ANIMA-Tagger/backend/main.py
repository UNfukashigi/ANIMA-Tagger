import sys
import os
import torch
import asyncio
import glob
import gc
import json
import re
import struct
import threading
import zlib
import numpy as np
import pandas as pd
import onnxruntime as ort
from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import tkinter as tk
from tkinter import filedialog
from PIL import Image
from huggingface_hub import hf_hub_download
from transformers import Qwen2VLForConditionalGeneration, AutoProcessor
from qwen_vl_utils import process_vision_info

import io

class WebSocketStderrRedirector(io.IOBase):
    def __init__(self, original_stderr):
        self.original_stderr = original_stderr

    def write(self, s):
        self.original_stderr.write(s)
        self.original_stderr.flush()
        if s.strip():
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(broadcast_log(s))
            except Exception:
                pass
        return len(s)

    def flush(self):
        self.original_stderr.flush()

app = FastAPI()

import webbrowser

def get_app_port():
    return int(os.environ.get("APP_PORT", "8010"))

@app.on_event("startup")
async def startup_event():
    async def open_browser():
        await asyncio.sleep(1.5)
        webbrowser.open(f"http://localhost:{get_app_port()}")
    asyncio.create_task(open_browser())

# Initialize tkinter for folder dialog
root = tk.Tk()
root.withdraw() # Hide main window
root.attributes('-topmost', True) # Bring dialog to front

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".webp"}
QWEN_MODEL_NAME = "Qwen/Qwen2-VL-2B-Instruct"
WD14_MODEL_NAME = "SmilingWolf/wd-swinv2-tagger-v3"
WD14_GENERAL_THRESHOLD = 0.35
WD14_CHARACTER_THRESHOLD = 0.85
ANIMA_STYLE_TAGS = {
    "anime style",
    "clean lineart",
    "soft shading",
    "cel shading",
    "detailed shading",
    "flat color",
    "pastel colors",
    "vivid colors",
    "muted colors",
    "high contrast",
    "low contrast",
    "rim lighting",
    "backlighting",
    "soft lighting",
    "dramatic lighting",
    "simple background",
    "white background",
    "transparent background",
    "full body",
    "upper body",
    "portrait",
    "cowboy shot",
    "dynamic pose",
    "symmetrical composition",
}
EXCLUDED_TAGS = {
    "masterpiece",
    "best quality",
    "high quality",
    "normal quality",
    "low quality",
    "worst quality",
    "highres",
    "absurdres",
    "official art",
    "artist name",
}
WORKFLOW_MARKERS = (
    '"inputs"',
    '"class_type"',
    '"_meta"',
    '"widgets_values"',
    '"nodes"',
    '"links"',
    "class_type",
    "_meta",
    "widgets_values",
)
PROMPT_METADATA_KEYS = {
    "anima_prompt",
    "anima prompt",
    "parameters",
    "prompt",
    "positive",
    "positive_prompt",
    "positive prompt",
    "caption",
    "description",
    "image_description",
    "image description",
    "imagedescription",
    "usercomment",
    "user_comment",
    "user comment",
    "270",
    "37510",
}

# Global logs and connection registry
tagger_logs = ""
tagger_running = False
active_connections: list[WebSocket] = []

def parse_png_text_chunks(image_path: str) -> dict[str, str]:
    chunks = {}
    try:
        with open(image_path, "rb") as f:
            data = f.read()

        if len(data) < 8 or data[:8] != b"\x89PNG\r\n\x1a\n":
            return chunks

        offset = 8
        while offset + 12 <= len(data):
            length = struct.unpack(">I", data[offset:offset + 4])[0]
            chunk_type = data[offset + 4:offset + 8].decode("latin-1", errors="ignore")
            chunk_data = data[offset + 8:offset + 8 + length]

            if chunk_type == "tEXt":
                null_index = chunk_data.find(b"\x00")
                if null_index != -1:
                    key = chunk_data[:null_index].decode("latin-1", errors="ignore")
                    value = chunk_data[null_index + 1:].decode("latin-1", errors="ignore")
                    try:
                        value = value.encode("latin-1").decode("utf-8")
                    except UnicodeDecodeError:
                        pass
                    chunks[key] = value

            elif chunk_type == "zTXt":
                null_index = chunk_data.find(b"\x00")
                if null_index != -1 and len(chunk_data) > null_index + 2:
                    key = chunk_data[:null_index].decode("latin-1", errors="ignore")
                    compressed = chunk_data[null_index + 2:]
                    try:
                        chunks[key] = zlib.decompress(compressed).decode("utf-8", errors="ignore")
                    except zlib.error:
                        pass

            elif chunk_type == "iTXt":
                ptr = chunk_data.find(b"\x00")
                if ptr != -1 and len(chunk_data) > ptr + 2:
                    key = chunk_data[:ptr].decode("utf-8", errors="ignore")
                    comp_flag = chunk_data[ptr + 1]
                    ptr += 3

                    lang_end = chunk_data.find(b"\x00", ptr)
                    if lang_end == -1:
                        offset += length + 12
                        continue

                    translated_end = chunk_data.find(b"\x00", lang_end + 1)
                    if translated_end == -1:
                        offset += length + 12
                        continue

                    text_data = chunk_data[translated_end + 1:]
                    if comp_flag == 1:
                        try:
                            text_data = zlib.decompress(text_data)
                        except zlib.error:
                            offset += length + 12
                            continue
                    chunks[key] = text_data.decode("utf-8", errors="ignore")

            if chunk_type == "IEND":
                break
            offset += length + 12
    except Exception:
        return {}

    return chunks

def recursive_find_comfy_text(flow: dict, input_value, visited: set[str] | None = None) -> str:
    if not input_value:
        return ""

    if visited is None:
        visited = set()

    node_id = str(input_value[0] if isinstance(input_value, list) else input_value)
    if node_id in visited:
        return ""
    visited.add(node_id)

    node = flow.get(node_id)
    if not isinstance(node, dict):
        return ""

    inputs = node.get("inputs")
    if not isinstance(inputs, dict):
        return ""

    value = inputs.get("value")
    if isinstance(value, str):
        return value

    for key in ("text", "prompt"):
        value = inputs.get(key)
        if isinstance(value, str):
            return value
        if isinstance(value, list):
            found = recursive_find_comfy_text(flow, value, visited)
            if found:
                return found

    if node.get("class_type") == "StringConcatenate":
        delimiter = inputs.get("delimiter")
        if not isinstance(delimiter, str):
            delimiter = ""
        parts = []
        for key in ("string_a", "string_b", "string_c", "string_d"):
            found = recursive_find_comfy_text(flow, inputs.get(key), visited)
            if found:
                parts.append(found)
        return delimiter.join(parts)

    for key in (
        "conditioning",
        "conditioning_1",
        "conditioning_2",
        "base_conditioning",
        "positive",
        "negative",
    ):
        if key in inputs:
            found = recursive_find_comfy_text(flow, inputs[key], visited)
            if found:
                return found

    return ""

def safe_find_comfy_prompt_text(flow: dict, input_value) -> str:
    if not input_value:
        return ""

    node_id = str(input_value[0] if isinstance(input_value, list) else input_value)
    node = flow.get(node_id)
    if not isinstance(node, dict):
        return ""

    inputs = node.get("inputs")
    if not isinstance(inputs, dict):
        return ""

    class_type = str(node.get("class_type", ""))
    allowed_direct_types = {
        "CLIPTextEncode",
        "CLIPTextEncodeSDXL",
        "CLIPTextEncodeSDXLRefiner",
        "Power Prompt (rgthree)",
    }
    if class_type not in allowed_direct_types:
        return ""

    for key in ("text", "prompt"):
        value = inputs.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    parts = [
        inputs.get(key).strip()
        for key in ("text_g", "text_l")
        if isinstance(inputs.get(key), str) and inputs.get(key).strip()
    ]
    return "\n".join(parts).strip()

def extract_positive_prompt_from_metadata(data: dict[str, str]) -> str:
    parameters = data.get("parameters")
    if isinstance(parameters, str) and parameters.strip():
        raw = parameters
        if any(marker in raw for marker in WORKFLOW_MARKERS):
            raw = re.split(r',\s*"\d+"\s*:\s*\{', raw, maxsplit=1)[0]
        neg_index = raw.rfind("\nNegative prompt: ")
        step_index = raw.rfind("\nSteps: ")

        if neg_index != -1:
            return raw[:neg_index].strip()
        if step_index != -1:
            return raw[:step_index].strip()
        return raw.strip()

    comfy_prompt = data.get("prompt")
    if isinstance(comfy_prompt, str) and comfy_prompt.strip():
        try:
            flow = json.loads(comfy_prompt)
            if isinstance(flow, dict):
                samplers = [
                    node for node in flow.values()
                    if isinstance(node, dict) and node.get("class_type") in {"KSampler", "KSamplerAdvanced"}
                ]
                if samplers:
                    positive = safe_find_comfy_prompt_text(flow, samplers[0].get("inputs", {}).get("positive"))
                    if positive:
                        return positive.strip()
        except json.JSONDecodeError:
            pass
        if looks_like_workflow_text(comfy_prompt):
            return ""

    if data.get("Software") == "NovelAI" or "NovelAI" in str(data.get("Source", "")) or data.get("Comment"):
        description = data.get("Description")
        if isinstance(description, str) and description.strip():
            return description.strip()
        comment = data.get("Comment")
        if isinstance(comment, str) and comment.strip():
            try:
                parsed = json.loads(comment)
                prompt = parsed.get("prompt")
                if isinstance(prompt, str):
                    return prompt.strip()
            except json.JSONDecodeError:
                return comment.strip()

    for key in PROMPT_METADATA_KEYS:
        value = get_metadata_value(data, key)
        if key == "prompt" and isinstance(value, str) and looks_like_workflow_text(value):
            continue
        if isinstance(value, str) and value.strip():
            return value.strip()

    return ""

def looks_like_workflow_text(text: str) -> bool:
    if not isinstance(text, str):
        return False
    stripped = text.lstrip()
    if stripped.startswith("{") and any(marker in stripped for marker in WORKFLOW_MARKERS):
        return True
    return any(marker in stripped for marker in ('"class_type"', '"widgets_values"', '"nodes"', '"links"'))

def get_metadata_value(data: dict[str, str], key: str) -> str:
    variants = {
        key,
        key.capitalize(),
        key.title(),
        key.replace("_", " "),
        key.replace(" ", "_"),
    }
    lower_map = {str(existing_key).lower(): existing_key for existing_key in data.keys()}

    for variant in variants:
        if variant in data:
            return data[variant]
        actual_key = lower_map.get(variant.lower())
        if actual_key is not None:
            return data[actual_key]

    return ""

def extract_prompt_text_from_image(image_path: str) -> str:
    metadata = parse_png_text_chunks(image_path)

    try:
        with Image.open(image_path) as img:
            for key, value in img.info.items():
                if isinstance(value, bytes):
                    value = value.decode("utf-8", errors="ignore")
                if isinstance(value, str) and value.strip():
                    metadata.setdefault(str(key), value.strip())

            exif = img.getexif()
            for tag_id in (270, 37510):
                value = exif.get(tag_id)
                if isinstance(value, bytes):
                    value = value.decode("utf-8", errors="ignore")
                if isinstance(value, str) and value.strip():
                    metadata.setdefault(str(tag_id), value.strip())
    except Exception:
        pass

    return extract_positive_prompt_from_metadata(metadata)

def prompt_text_to_tags(prompt_text: str) -> list[str]:
    if not prompt_text:
        return []

    if looks_like_workflow_text(prompt_text):
        return []

    prompt_text = re.split(r',\s*"\d+"\s*:\s*\{', prompt_text, maxsplit=1)[0]
    prompt_text = re.split(r"\bNegative prompt:\b|\bSteps:\b|\bSampler:\b", prompt_text, maxsplit=1, flags=re.IGNORECASE)[0]
    prompt_text = re.sub(r"<[^>]+>", "", prompt_text)
    prompt_text = re.sub(r"\([^)]*:[0-9.]+[^)]*\)", "", prompt_text)
    prompt_text = re.sub(r"\[[^\]]*:[0-9.]+[^\]]*\]", "", prompt_text)
    prompt_text = prompt_text.replace("\n", ",")

    tags = []
    for raw_tag in prompt_text.split(","):
        tag = raw_tag.strip().lower()
        tag = re.sub(r"^[({\[]+|[)}\]]+$", "", tag).strip()
        tag = re.sub(r"\s+", " ", tag)
        if not tag or len(tag) > 80:
            continue
        if looks_like_workflow_text(tag):
            continue
        if any(marker.strip('"') in tag for marker in WORKFLOW_MARKERS):
            continue
        if any(char in tag for char in ('"', "{", "}", "[", "]")):
            continue
        if re.search(r"\b(inputs|class_type|widgets_values|last_node_id|last_link_id|filename_prefix)\b", tag):
            continue
        if tag.count(":") > 1 or re.search(r'"\s*:', tag):
            continue
        if re.fullmatch(r"[\W_]+", tag):
            continue
        tags.append(tag)
    return tags

def dedupe_tags(tags: list[str]) -> list[str]:
    seen = set()
    deduped = []
    for tag in tags:
        normalized = tag.strip()
        key = normalized.lower()
        if key.isdigit():
            continue
        if key in EXCLUDED_TAGS:
            continue
        if normalized and key not in seen:
            seen.add(key)
            deduped.append(normalized)
    return deduped

def normalize_tag_text(tag: str) -> str:
    tag = tag.strip().lower()
    tag = tag.replace("_", " ")
    tag = re.sub(r"\s+", " ", tag)
    return tag

def load_wd14_tagger():
    model_path = hf_hub_download(WD14_MODEL_NAME, "model.onnx")
    tags_path = hf_hub_download(WD14_MODEL_NAME, "selected_tags.csv")
    providers = ["CPUExecutionProvider"]
    session = ort.InferenceSession(model_path, providers=providers)
    tags_df = pd.read_csv(tags_path)
    return session, tags_df

def prepare_wd14_image(image_path: str, target_size: int) -> np.ndarray:
    with Image.open(image_path) as img:
        img = img.convert("RGB")
        width, height = img.size
        side = max(width, height)
        canvas = Image.new("RGB", (side, side), (255, 255, 255))
        canvas.paste(img, ((side - width) // 2, (side - height) // 2))
        resampling = getattr(Image, "Resampling", Image).LANCZOS
        canvas = canvas.resize((target_size, target_size), resampling)

    image = np.asarray(canvas, dtype=np.float32)
    image = image[:, :, ::-1]
    return np.expand_dims(image, axis=0)

def run_wd14_tagger(session, tags_df: pd.DataFrame, image_path: str) -> list[str]:
    input_name = session.get_inputs()[0].name
    output_name = session.get_outputs()[0].name
    input_shape = session.get_inputs()[0].shape
    target_size = int(input_shape[1] or 448)

    image = prepare_wd14_image(image_path, target_size)
    probs = session.run([output_name], {input_name: image})[0][0]

    tags = []
    for idx, probability in enumerate(probs[:len(tags_df)]):
        row = tags_df.iloc[idx]
        category = int(row.get("category", 0))
        if category == 9:
            continue
        if category == 4 and probability < WD14_CHARACTER_THRESHOLD:
            continue
        if category != 4 and probability < WD14_GENERAL_THRESHOLD:
            continue

        name = str(row["name"])
        tag = normalize_tag_text(name)
        if tag:
            tags.append(tag)

    return tags

def split_qwen_tags(output_text: str) -> list[str]:
    tags = []
    for raw_tag in output_text.split(","):
        tag = normalize_tag_text(raw_tag)
        if not tag or len(tag) > 80:
            continue
        if tag.isdigit():
            continue
        if any(marker.strip('"') in tag for marker in WORKFLOW_MARKERS):
            continue
        if any(char in tag for char in ('"', "{", "}", "[", "]")):
            continue
        if re.fullmatch(r"[\W_]+", tag):
            continue
        if tag:
            tags.append(tag)
    return tags

@app.websocket("/ws/logs")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    active_connections.append(websocket)
    try:
        await websocket.send_text("--- Connection Established ---")
        while True:
            await asyncio.sleep(1)
    except WebSocketDisconnect:
        active_connections.remove(websocket)

async def broadcast_log(line: str):
    global tagger_logs
    tagger_logs += line
    # Keep logs size reasonable
    if len(tagger_logs) > 20000:
        tagger_logs = tagger_logs[-20000:]

    if threading.current_thread() is not threading.main_thread():
        return
        
    for connection in active_connections:
        try:
            await connection.send_text(line)
        except:
            pass

class TaggerConfig(BaseModel):
    folder_path: str
    trigger_word: str

@app.get("/api/browse-folder")
async def browse_folder():
    try:
        folder_path = filedialog.askdirectory(title="Select Dataset Folder")
        if folder_path:
            return {"path": folder_path}
        return {"path": ""}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/dataset/images")
async def list_images(path: str):
    if not os.path.exists(path):
        raise HTTPException(status_code=404, detail="Path not found")
    
    files = []
    # Search for all image files
    for f in os.listdir(path):
        ext = os.path.splitext(f)[1].lower()
        if ext in IMAGE_EXTENSIONS:
            base = os.path.splitext(f)[0]
            image_path = os.path.join(path, f)
            txt_path = os.path.join(path, base + ".txt")
            tags = []
            if os.path.exists(txt_path):
                with open(txt_path, "r", encoding="utf-8") as tf:
                    raw_tags = tf.read().split(",")
                    for t in raw_tags:
                        t = t.strip()
                        if t:
                            tags.append(t)
                    tags = dedupe_tags(tags)
            else:
                tags = dedupe_tags(prompt_text_to_tags(extract_prompt_text_from_image(image_path)))
            
            files.append({
                "name": f,
                "path": image_path,
                "tags": tags
            })
    return {"files": files}

class TagUpdate(BaseModel):
    path: str
    tags: list[str]

@app.post("/api/dataset/update-tags")
async def update_tags(update: TagUpdate):
    base = os.path.splitext(update.path)[0]
    txt_path = base + ".txt"
    try:
        with open(txt_path, "w", encoding="utf-8") as f:
            f.write(", ".join(dedupe_tags(update.tags)))
        return {"status": "success"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/image")
async def get_image(path: str):
    if not os.path.exists(path):
        raise HTTPException(status_code=404)
    return FileResponse(path)

@app.post("/api/run-tagger")
async def run_tagger(config: TaggerConfig):
    global tagger_running, tagger_logs
    if tagger_running:
        return {"status": "error", "message": "Tagger is already running"}
    
    try:
        tagger_running = True
        tagger_logs = ""
        await broadcast_log("Starting tagger worker...\n")
        worker = threading.Thread(
            target=lambda: asyncio.run(tagger_task(config)),
            daemon=True
        )
        worker.start()
        return {"status": "started"}
    except Exception as e:
        tagger_running = False
        return {"status": "error", "message": str(e)}

@app.get("/api/tagger-status")
async def get_tagger_status():
    return {"running": tagger_running}

@app.get("/api/tagger-logs")
async def get_tagger_logs():
    return {"logs": tagger_logs, "running": tagger_running}

async def tagger_task(config: TaggerConfig):
    global tagger_running, tagger_logs
    await broadcast_log("Initializing Qwen-VL Tagger...\n")
    
    image_paths = []
    for ext in IMAGE_EXTENSIONS:
        image_paths.extend(glob.glob(os.path.join(config.folder_path, f"*{ext}")))
        image_paths.extend(glob.glob(os.path.join(config.folder_path, f"*{ext.upper()}")))
    image_paths = sorted(set(os.path.normcase(os.path.abspath(path)) for path in image_paths))
        
    if not image_paths:
        await broadcast_log("Error: No images found in the specified folder.\n")
        tagger_running = False
        return
        
    total_images = len(image_paths)
    await broadcast_log(f"Found {total_images} images. Loading WD14 + Qwen models...\n")
    
    try:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        wd_session = None
        wd_tags_df = None

        try:
            await broadcast_log(f"Loading WD14 tagger: {WD14_MODEL_NAME}...\n")
            wd_session, wd_tags_df = load_wd14_tagger()
            await broadcast_log("WD14 tagger loaded successfully.\n")
        except Exception as e:
            await broadcast_log(f"Warning: WD14 tagger could not be loaded, continuing with Qwen only: {str(e)}\n")
        
        original_stderr = sys.stderr
        sys.stderr = WebSocketStderrRedirector(original_stderr)
        try:
            model = Qwen2VLForConditionalGeneration.from_pretrained(
                QWEN_MODEL_NAME,
                torch_dtype=torch.float16 if device == "cuda" else torch.float32,
                device_map="auto" if device == "cuda" else None
            )
            processor = AutoProcessor.from_pretrained(QWEN_MODEL_NAME)
        finally:
            sys.stderr = original_stderr
            
        await broadcast_log("Model loaded successfully! Generating tags...\n")
        
    except Exception as e:
        await broadcast_log(f"Error loading model: {str(e)}\n")
        tagger_running = False
        return

    try:
        for idx, img_path in enumerate(image_paths):
            await broadcast_log(f"\nProcessing [{idx + 1}/{total_images}]: {os.path.basename(img_path)}...\n")
            wd_tags = []
            if wd_session is not None and wd_tags_df is not None:
                try:
                    wd_tags = run_wd14_tagger(wd_session, wd_tags_df, img_path)
                    await broadcast_log(f"WD14 tags: {', '.join(wd_tags) if wd_tags else '(none)'}\n")
                except Exception as e:
                    await broadcast_log(f"Warning: WD14 failed for this image: {str(e)}\n")
            wd_context = ", ".join(wd_tags[:60]) if wd_tags else "(none)"
            
            messages = [
                {
                    "role": "user",
                    "content": [
                        {"type": "image", "image": img_path},
                        {"type": "text", "text": (
                            "WD14 already detected these Danbooru-style base tags: "
                            f"{wd_context}. "
                            "Add only useful supplemental tags for ANIMA LoRA training that WD14 often misses. "
                            "Focus on art style, rendering style, line quality, shading, color palette, lighting, composition, framing, camera angle, background simplicity, and visible pose nuance. "
                            "Also add a few obvious missing visual tags only if they are not already in the WD14 tags. "
                            "Prefer concise ANIMA/Danbooru-understandable tags such as anime style, clean lineart, soft shading, cel shading, detailed shading, flat color, pastel colors, vivid colors, muted colors, soft lighting, rim lighting, backlighting, simple background, white background, full body, upper body, portrait, cowboy shot, looking at viewer, standing, sitting. "
                            "Do not repeat WD14 tags. Do not invent hidden details, names, copyrighted character names, artist names, ratings, or quality tags. "
                            "Output 6 to 18 lowercase comma-separated tags. "
                            "Rules: use ONLY commas as separators, no sentences, no dashes, no bullet points, no newlines, no numbering, no explanations. "
                            "Example output: anime style, clean lineart, soft shading, simple background, full body, looking at viewer"
                        )}
                    ]
                }
            ]
            
            text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
            image_inputs, video_inputs = process_vision_info(messages)
            
            inputs = processor(
                text=[text],
                images=image_inputs,
                videos=video_inputs,
                padding=True,
                return_tensors="pt"
            )
            inputs = inputs.to(device)
            
            with torch.no_grad():
                generated_ids = model.generate(**inputs, max_new_tokens=256)
                generated_ids_trimmed = [
                    out_ids[len(in_ids):] for in_ids, out_ids in zip(inputs.input_ids, generated_ids)
                ]
                output_text = processor.batch_decode(
                    generated_ids_trimmed, skip_special_tokens=True, clean_up_tokenization_spaces=False
                )[0]
            
            # Clean and parse tags
            qwen_tags = split_qwen_tags(output_text)
            metadata_tags = prompt_text_to_tags(extract_prompt_text_from_image(img_path))
            if metadata_tags:
                await broadcast_log(f"Metadata prompt tags found: {len(metadata_tags)}\n")
            if qwen_tags:
                await broadcast_log(f"Qwen supplemental tags: {', '.join(qwen_tags)}\n")

            tags_list = dedupe_tags(metadata_tags + wd_tags + qwen_tags)
            
            # Inject trigger word at the front
            if config.trigger_word:
                trigger = config.trigger_word.strip()
                if trigger not in tags_list:
                    tags_list.insert(0, trigger)
                else:
                    tags_list.remove(trigger)
                    tags_list.insert(0, trigger)
                    
            final_tags_str = ", ".join(tags_list)
            
            txt_path = os.path.splitext(img_path)[0] + ".txt"
            with open(txt_path, "w", encoding="utf-8") as f:
                f.write(final_tags_str)
                
            await broadcast_log(f"Tags: {final_tags_str}\n")
            await broadcast_log(f"✅ {idx + 1}/{total_images} complete...\n")
            
        await broadcast_log("\n--- Tagging Completed Successfully ---\n")
        
    except Exception as e:
        await broadcast_log(f"Error during tagging: {str(e)}\n")
        
    finally:
        # Strict memory cleanup to avoid GPU lock
        del model
        del processor
        if device == "cuda":
            torch.cuda.empty_cache()
        gc.collect()
        tagger_running = False

# Mount Frontend static files
app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=get_app_port())
