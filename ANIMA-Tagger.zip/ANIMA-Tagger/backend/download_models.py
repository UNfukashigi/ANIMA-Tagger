import sys
import os
import torch
from huggingface_hub import hf_hub_download
from transformers import Qwen2VLForConditionalGeneration, AutoProcessor

MODEL_NAME = "Qwen/Qwen2-VL-2B-Instruct"
WD14_MODEL_NAME = "SmilingWolf/wd-swinv2-tagger-v3"

def main():
    print(f"\n===================================================")
    print(f"[INFO] Pre-downloading model: {MODEL_NAME}")
    print(f"[INFO] Mode: FP16 (no quantization - stable on all GPUs)")
    print(f"[INFO] This runs only once to cache the files (~4-5GB).")
    print(f"===================================================\n")
    
    try:
        print("[INFO] Downloading processor...")
        AutoProcessor.from_pretrained(MODEL_NAME)
        
        print("[INFO] Downloading model weights (this might take a few minutes)...")
        Qwen2VLForConditionalGeneration.from_pretrained(
            MODEL_NAME,
            torch_dtype=torch.float32,
            low_cpu_mem_usage=True,
            device_map=None
        )
        print(f"\n[INFO] Pre-downloading WD14 tagger: {WD14_MODEL_NAME}")
        hf_hub_download(WD14_MODEL_NAME, "model.onnx")
        hf_hub_download(WD14_MODEL_NAME, "selected_tags.csv")
        print(f"\n[SUCCESS] Model {MODEL_NAME} has been downloaded and cached successfully!")
    except Exception as e:
        print(f"\n[ERROR] Model download failed: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
